export const searchFields = [
  {
    title: "Job Title",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-search text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" />
        <path d="M21 21l-6 -6" />
      </svg>
    ),
    options: [
      "Designer",
      "Developer",
      "Product Manager",
      "Marketing Specialist",
      "Data Analyst",
      "Sales Executive",
      "Content Writer",
      "Customer Support",
    ],
  },
  {
    title: "Location",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-map-pin-check text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M9 11a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" />
        <path d="M11.87 21.48a1.992 1.992 0 0 1 -1.283 -.58l-4.244 -4.243a8 8 0 1 1 13.355 -3.474" />
        <path d="M15 19l2 2l4 -4" />
      </svg>
    ),
    options: [
      "Delhi",
      "New York",
      "San Francisco",
      "London",
      "Berlin",
      "Tokyo",
      "Sydney",
      "Toronto",
    ],
  },

  {
    title: "Skill",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-recharging text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M7.038 4.5a9 9 0 0 0 -2.495 2.47" />
        <path d="M3.186 10.209a9 9 0 0 0 0 3.508" />
        <path d="M4.5 16.962a9 9 0 0 0 2.47 2.495" />
        <path d="M10.209 20.814a9 9 0 0 0 3.5 0" />
        <path d="M16.962 19.5a9 9 0 0 0 2.495 -2.47" />
        <path d="M20.814 13.791a9 9 0 0 0 0 -3.508" />
        <path d="M19.5 7.038a9 9 0 0 0 -2.47 -2.495" />
        <path d="M13.791 3.186a9 9 0 0 0 -3.508 -.02" />
        <path d="M12 8l-2 4h4l-2 4" />
        <path d="M12 21a9 9 0 0 0 0 -18" />
      </svg>
    ),
    options: [
      "JavaScript",
      "Python",
      "Java",
      "Spring Boot",
      "React",
      "Node.js",
      "Database Management",
      "Version Control (Git)",
      "Agile Methodologies",
      "Project Planning",
      "Roadmap Development",
      "Stakeholder Communication",
      "Market Research",
      "Data Analysis",
      "Team Leadership",
      "Risk Management",
      "Data Visualization",
      "SQL",
    ],
  },
];

export const talents = [
  {
    name: "Jarrod Wood",
    role: "Software Engineer",
    company: "Google",
    topSkills: ["React", "SpringBoot", "MongoDB"],
    about:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur alias nostrum omnis ipsam doloribus odit adipisci veniam dolore ea iste libero pariatur tempora neque blanditiis, minima accusamus sit reiciendis labore.",
    expectedCtc: "$48 - 60LPA",
    location: "New York, United States",
    image: "avatar",
  },
  {
    name: "Jarrod Wood",
    role: "Software Engineer",
    company: "Google",
    topSkills: ["React", "SpringBoot", "MongoDB"],
    about:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur alias nostrum omnis ipsam doloribus odit adipisci veniam dolore ea iste libero pariatur tempora neque blanditiis, minima accusamus sit reiciendis labore.",
    expectedCtc: "$48 - 60LPA",
    location: "New York, United States",
    image: "avatar",
  },
  {
    name: "Jarrod Wood",
    role: "Software Engineer",
    company: "Google",
    topSkills: ["React", "SpringBoot", "MongoDB"],
    about:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur alias nostrum omnis ipsam doloribus odit adipisci veniam dolore ea iste libero pariatur tempora neque blanditiis, minima accusamus sit reiciendis labore.",
    expectedCtc: "$48 - 60LPA",
    location: "New York, United States",
    image: "avatar",
  },
  {
    name: "Jarrod Wood",
    role: "Software Engineer",
    company: "Google",
    topSkills: ["React", "SpringBoot", "MongoDB"],
    about:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur alias nostrum omnis ipsam doloribus odit adipisci veniam dolore ea iste libero pariatur tempora neque blanditiis, minima accusamus sit reiciendis labore.",
    expectedCtc: "$48 - 60LPA",
    location: "New York, United States",
    image: "avatar",
  },
  {
    name: "Jarrod Wood",
    role: "Software Engineer",
    company: "Google",
    topSkills: ["React", "SpringBoot", "MongoDB"],
    about:
      "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Tenetur alias nostrum omnis ipsam doloribus odit adipisci veniam dolore ea iste libero pariatur tempora neque blanditiis, minima accusamus sit reiciendis labore.",
    expectedCtc: "$48 - 60LPA",
    location: "New York, United States",
    image: "avatar",
  },
];

export const profile = {
  name: "Jarrod Wood",
  role: "Software Engineer",
  company: "Google",
  location: "New York, United States",
  about:
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consectetur, aliquam nostrum. Quae nemo blanditiis dolores a soluta error odit voluptatum? Eos tempore maiores fugiat, quam tempora vel consequatur! Voluptates, laboriosam!",
  skills: [
    "React",
    "SpringBoot",
    "MongoDB",
    "HTML",
    "CSS",
    "JavaScript",
    "Node.js",
    "MySQL",
    "Python",
    "Django",
    "Figma",
    "Sketch",
    "Docker",
    "AWS",
  ],
  experience: [
    {
      title: "Software Engineer",
      company: "Google",
      location: "New York, United States",
      startDate: "Apr 2022",
      endDate: "Present",
      description:
        "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consectetur, aliquam nostrum. Quae nemo blanditiis dolores a soluta error odit voluptatum? Eos tempore maiores fugiat, quam tempora vel consequatur! Voluptates, laboriosam!",
    },
    {
      title: "Software Engineer",
      company: "Microsoft",
      location: "New York, United States",
      startDate: "July 2020",
      endDate: "Feb 2022",
      description:
        "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consectetur, aliquam nostrum. Quae nemo blanditiis dolores a soluta error odit voluptatum? Eos tempore maiores fugiat, quam tempora vel consequatur! Voluptates, laboriosam!",
    },
  ],
  certifications: [
    {
      name: "Google Professional Cloud Architect",
      issuer: "Google",
      issueDate: "Aug 2023",
      certificateId: "CB72982GG",
    },
    {
      name: "Microsoft Certified:Azure Solutions Architect Expert",
      issuer: "Microsoft",
      issueDate: "Jan 2024",
      certificateId: "AW43589BV",
    },
  ],
};
