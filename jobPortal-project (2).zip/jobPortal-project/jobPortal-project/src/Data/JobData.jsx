export const dropdownData = [
  {
    title: "Job Title",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-search text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" />
        <path d="M21 21l-6 -6" />
      </svg>
    ),
    options: [
      "Designer",
      "Developer",
      "Product Manager",
      "Marketing Specialist",
      "Data Analyst",
      "Sales Executive",
      "Content Writer",
      "Customer Support",
    ],
  },
  {
    title: "Location",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-map-pin-check text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M9 11a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" />
        <path d="M11.87 21.48a1.992 1.992 0 0 1 -1.283 -.58l-4.244 -4.243a8 8 0 1 1 13.355 -3.474" />
        <path d="M15 19l2 2l4 -4" />
      </svg>
    ),
    options: [
      "Delhi",
      "New York",
      "San Francisco",
      "London",
      "Berlin",
      "Tokyo",
      "Sydney",
      "Toronto",
    ],
  },
  {
    title: "Experience",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-briefcase text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M3 7m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v9a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z" />
        <path d="M8 7v-2a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v2" />
        <path d="M12 12l0 .01" />
        <path d="M3 13a20 20 0 0 0 18 0" />
      </svg>
    ),
    options: ["Entry Level", "Intermediate", "Expert"],
  },
  {
    title: "Job Type",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-recharging text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M7.038 4.5a9 9 0 0 0 -2.495 2.47" />
        <path d="M3.186 10.209a9 9 0 0 0 0 3.508" />
        <path d="M4.5 16.962a9 9 0 0 0 2.47 2.495" />
        <path d="M10.209 20.814a9 9 0 0 0 3.5 0" />
        <path d="M16.962 19.5a9 9 0 0 0 2.495 -2.47" />
        <path d="M20.814 13.791a9 9 0 0 0 0 -3.508" />
        <path d="M19.5 7.038a9 9 0 0 0 -2.47 -2.495" />
        <path d="M13.791 3.186a9 9 0 0 0 -3.508 -.02" />
        <path d="M12 8l-2 4h4l-2 4" />
        <path d="M12 21a9 9 0 0 0 0 -18" />
      </svg>
    ),
    options: ["Full Time", "Part Time", "Contract", "Freelance", "Internship"],
  },
];

export const jobList = [
  {
    jobTitle: "Product Designer",
    company: "META",
    applicants: 25,
    experience: "Entry Level",
    jobType: "Full-Time",
    location: "New York",
    package: "32 LPA",
    postedDaysAgo: 12,
    description:
      " Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorepariatur, eveniet deleniti, neque laudantium corporis porro cumque vercorrupti cupiditate odit fugiat?",
  },
  {
    jobTitle: "Sr. UI/UX designer",
    company: "Microsoft",
    applicants: 25,
    experience: "Entry Level",
    jobType: "Full-Time",
    location: "London",
    package: "32 LPA",
    postedDaysAgo: 12,
    description:
      " Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorepariatur, eveniet deleniti, neque laudantium corporis porro cumque vercorrupti cupiditate odit fugiat?",
  },
  {
    jobTitle: "Project Manager",
    company: "Google",
    applicants: 25,
    experience: "Entry Level",
    jobType: "Full-Time",
    location: "New York",
    package: "32 LPA",
    postedDaysAgo: 12,
    description:
      " Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorepariatur, eveniet deleniti, neque laudantium corporis porro cumque vercorrupti cupiditate odit fugiat?",
  },
  {
    jobTitle: "Jr Developer",
    company: "figma",
    applicants: 25,
    experience: "Entry Level",
    jobType: "Full-Time",
    location: "New York",
    package: "32 LPA",
    postedDaysAgo: 12,
    description:
      " Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorepariatur, eveniet deleniti, neque laudantium corporis porro cumque vercorrupti cupiditate odit fugiat?",
  },
  {
    jobTitle: "Java Developer",
    company: "oracle",
    applicants: 25,
    experience: "Entry Level",
    jobType: "Full-Time",
    location: "New York",
    package: "32 LPA",
    postedDaysAgo: 12,
    description:
      " Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorepariatur, eveniet deleniti, neque laudantium corporis porro cumque vercorrupti cupiditate odit fugiat?",
  },
  {
    jobTitle: "Sale Manager",
    company: "Amazon",
    applicants: 25,
    experience: "Entry Level",
    jobType: "Full-Time",
    location: "New York",
    package: "32 LPA",
    postedDaysAgo: 12,
    description:
      " Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorepariatur, eveniet deleniti, neque laudantium corporis porro cumque vercorrupti cupiditate odit fugiat?",
  },
  {
    jobTitle: "Database Adminstrator",
    company: "netflix",
    applicants: 25,
    experience: "Entry Level",
    jobType: "Full-Time",
    location: "New York",
    package: "32 LPA",
    postedDaysAgo: 12,
    description:
      " Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorepariatur, eveniet deleniti, neque laudantium corporis porro cumque vercorrupti cupiditate odit fugiat?",
  },
];
