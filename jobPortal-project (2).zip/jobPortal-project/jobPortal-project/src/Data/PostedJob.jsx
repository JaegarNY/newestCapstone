export const activeJobs = [
  {
    jobTitle: "Frontend Developer",
    location: "San Francisco, USA",
    posted: "5 days ago",
  },
  {
    jobTitle: "Backend Engineer",
    location: "London, UK",
    posted: "2 days ago",
  },
  {
    jobTitle: "Full Stack Developer",
    location: "Sydney, Australia",
    posted: "7 days ago",
  },
  {
    jobTitle: "UI/UX Designer",
    location: "Toronto, CAndana",
    posted: "1 days ago",
  },
];
