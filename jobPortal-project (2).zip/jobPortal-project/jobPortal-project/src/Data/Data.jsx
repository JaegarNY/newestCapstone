export const companies = [
  "google",
  "amazon",
  "figma",
  "netflix",
  "META",
  "microsoft",
  "pinterest",
  "slack",
  "spotify",
  "oracle",
  "walmart",
];
export const jobCategory = [
  "digital marketing",
  "education",
  "healthcare",
  "art",
  "information technology",
  "science",
  "general manager",
];

export const work = [
  {
    name: "Build your Resume",
    desc: "Create a standout resume with your skills.",
  },
  {
    name: "Apply for Job",
    desc: "Find and apply for  jobs that match your skills.",
  },
  {
    name: "Get Hired",
    desc: "Connect with employers and start your new job.",
  },
];

export const testimonials = [
  {
    name: "Shivam Patel",
    testimonial:
      "This job portal made job search easy and quick. Recommended to all job seekers",
    rating: 5,
  },
  {
    name: "Abhishek Kullu",
    testimonial:
      "Found my dream job within a week! The application process was smooth.",
    rating: 5,
  },
  {
    name: "Swapnil Pandey",
    testimonial:
      "I secured a job offer within days of applying. Exceptional user experience and support.",
    rating: 4,
  },
];

export const footerLinks = [
  { title: "Product", links: ["Find Job", "Find Company", "Find Employee"] },
  {
    title: "Company",
    links: ["About Us", "Contact Us", "Privacy Policy", "Terms & Conditions"],
  },
  { title: "Support", links: ["Help & Support", "Feedback", "FAQs"] },
];
