export const card = [
  {
    name: "Location",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-map-pin-check text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M9 11a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" />
        <path d="M11.87 21.48a1.992 1.992 0 0 1 -1.283 -.58l-4.244 -4.243a8 8 0 1 1 13.355 -3.474" />
        <path d="M15 19l2 2l4 -4" />
      </svg>
    ),
    value: "New York",
  },
  {
    name: "Experience",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-briefcase text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M3 7m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v9a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z" />
        <path d="M8 7v-2a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v2" />
        <path d="M12 12l0 .01" />
        <path d="M3 13a20 20 0 0 0 18 0" />
      </svg>
    ),
    value: "Expert",
  },
  {
    name: "Salary",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="currentColor"
        className="icon icon-tabler icons-tabler-filled icon-tabler-coin text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M17 3.34a10 10 0 1 1 -15 8.66l.005 -.324a10 10 0 0 1 14.995 -8.336zm-5 2.66a1 1 0 0 0 -1 1a3 3 0 1 0 0 6v2a1.024 1.024 0 0 1 -.866 -.398l-.068 -.101a1 1 0 0 0 -1.732 .998a3 3 0 0 0 2.505 1.5h.161a1 1 0 0 0 .883 .994l.117 .007a1 1 0 0 0 1 -1l.176 -.005a3 3 0 0 0 -.176 -5.995v-2c.358 -.012 .671 .14 .866 .398l.068 .101a1 1 0 0 0 1.732 -.998a3 3 0 0 0 -2.505 -1.501h-.161a1 1 0 0 0 -1 -1zm1 7a1 1 0 0 1 0 2v-2zm-2 -4v2a1 1 0 0 1 0 -2z" />
      </svg>
    ),
    value: "48 LPA",
  },
  {
    name: "Job Type",
    icon: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="icon icon-tabler icons-tabler-outline icon-tabler-recharging text-bright-sun-400 p-1 bg-mine-shaft-900 rounded-full mr-2"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M7.038 4.5a9 9 0 0 0 -2.495 2.47" />
        <path d="M3.186 10.209a9 9 0 0 0 0 3.508" />
        <path d="M4.5 16.962a9 9 0 0 0 2.47 2.495" />
        <path d="M10.209 20.814a9 9 0 0 0 3.5 0" />
        <path d="M16.962 19.5a9 9 0 0 0 2.495 -2.47" />
        <path d="M20.814 13.791a9 9 0 0 0 0 -3.508" />
        <path d="M19.5 7.038a9 9 0 0 0 -2.47 -2.495" />
        <path d="M13.791 3.186a9 9 0 0 0 -3.508 -.02" />
        <path d="M12 8l-2 4h4l-2 4" />
        <path d="M12 21a9 9 0 0 0 0 -18" />
      </svg>
    ),
    value: "Full Time",
  },
];
export const skills = [
  "React",
  "SpringBoot",
  "MongoDB",
  "HTML",
  "CSS",
  "JavaScript",
  "Node.js",
  "MySQL",
  "Python",
  "Django",
  "Figma",
  "Sketch",
  "Docker",
  "AWS",
];
export const desc =
  " <header><h1>Software Developer</h1><p><strong>Company:</strong> Tech Innovators Inc.</p></header><section><h2>Job Overview</h2><p>The Software Developer will be responsible for creating and maintaining software applications, collaborating with cross-functional teams, and improving existing systems. The position requires strong problem-solving skills, attention to detail, and the ability to work in a fast-paced environment.</p></section><section><h2>Key Responsibilities</h2><ul><li>Design, develop, and maintain software applications.</li><li>Collaborate with other developers, designers, and product managers.</li><li>Write clean, efficient, and scalable code.</li><li>Participate in code reviews and provide constructive feedback.</li><li>Ensure the functionality and performance of applications.</li></ul></section><section><h2>Qualifications</h2><ol><li>Bachelor's degree in Computer Science or related field.</li><li>Proficiency in programming languages such as Java, Python, or JavaScript.</li><li>Experience with web development frameworks like React, Angular, or Node.js.</li><li>Familiarity with databases and cloud platforms.</li><li>Strong problem-solving and debugging skills.</li></ol></section><section><h2>Benefits</h2><ul><li>Competitive salary.</li><li>Health, dental, and vision insurance.</li><li>Flexible working hours and remote work options.</li><li>Opportunities for career growth and development.</li></ul></section><footer></footer>";
