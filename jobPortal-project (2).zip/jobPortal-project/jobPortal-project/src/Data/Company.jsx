export const companyData = {
  Name: "Google",
  Overview:
    "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorepariatur, eveniet deleniti, neque laudantium corporis porro cumque vercorrupti cupiditate odit fugiat?",
  Industry: "Internet, Software & Technology Services",
  Website: "https://www.google.com",
  Size: "100,000+ Employees",
  Headquarters: "Mountain View, California, United States",
  Specialities: ["Search Engine", "Online Advertising", "Cloud Computing"],
};
export const similar = [
  {
    name: "META",
    employees: 58604,
  },
  {
    name: "Netflix",
    employees: 12800,
  },
  {
    name: "Microsoft",
    employees: 221000,
  },
];
