import { Checkbox, Textarea, Button } from "@mantine/core";
import { fields } from "../Data/Profile";
import SelectInput from "./SelectInput";
import { useState } from "react";
import { MonthPickerInput } from "@mantine/dates";
export default function ExpInput(props) {
  const select = fields;
  const [checked, setChecked] = useState(false);
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [desc, setDesc] = useState(
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consectetur, aliquam nostrum. Quae nemo blanditiis dolores a soluta error odit voluptatum? Eos tempore maiores fugiat, quam tempora vel consequatur! Voluptates, laboriosam!"
  );
  return (
    <div className="flex flex-col gap-3">
      <div className="text-lg font-semibold">
        {props.add ? "Add Experience" : "Edit Experience"}
      </div>
      <div className="text-mine-shaft-100 flex gap-10 [&>*]:w-1/2">
        <SelectInput {...select[0]} />
        <SelectInput {...select[1]} />
      </div>

      <SelectInput {...select[2]} />
      <Textarea
        withAsterisk
        label="Summary"
        autosize
        minRows={3}
        value={desc}
        placeholder="Enter Summary..."
        onChange={(e) => setAbout(e.currentTarget.value)}
      />
      <div className="text-mine-shaft-100 flex gap-10 [&>*]:w-1/2">
        <MonthPickerInput
          withAsterisk
          maxDate={endDate || new Date() || undefined}
          label="Start Date"
          placeholder="Pick Date"
          value={startDate}
          onChange={setStartDate}
        />
        <MonthPickerInput
          withAsterisk
          disabled={checked}
          label="End Date"
          minDate={startDate || undefined}
          maxDate={new Date()}
          placeholder="Pick Date"
          value={endDate}
          onChange={setEndDate}
        />
      </div>
      <Checkbox
        autoContrast
        checked={checked}
        onChange={(e) => setChecked(e.currentTarget.checked)}
        label="
          currently
          working
          here"
      />
      <div className="flex gap-5">
        <Button
          onClick={() => props.setEdit(false)}
          color="#ffbd20"
          variant="outline"
        >
          Save
        </Button>
        <Button
          color="#b22222"
          onClick={() => props.setEdit(false)}
          variant="light"
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}
