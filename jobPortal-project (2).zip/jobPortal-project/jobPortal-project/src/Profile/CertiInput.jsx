import { Checkbox, Textarea, Button, TextInput } from "@mantine/core";
import { fields } from "../Data/Profile";
import SelectInput from "./SelectInput";
import { useState } from "react";
import { MonthPickerInput } from "@mantine/dates";
export default function CertiInput(props) {
  const select = fields;
  const [issueDate, setIssueDate] = useState(new Date());
  return (
    <div className="flex flex-col gap-3">
      <div className="text-lg font-semibold">Add Certificate</div>
      <div className="text-mine-shaft-100 flex gap-10 [&>*]:w-1/2">
        <TextInput label="Title" withAsterisk placeholder="Enter title" />
        <SelectInput {...select[1]} />
      </div>
      <div className="text-mine-shaft-100 flex gap-10 [&>*]:w-1/2">
        <MonthPickerInput
          withAsterisk
          maxDate={new Date()}
          label="Issue Date"
          placeholder="Pick Date"
          value={issueDate}
          onChange={setIssueDate}
        />
        <TextInput label="Certificate ID" withAsterisk placeholder="Enter ID" />
      </div>

      <div className="flex gap-5">
        <Button
          onClick={() => props.setEdit(false)}
          color="#ffbd20"
          variant="outline"
        >
          Save
        </Button>
        <Button
          color="#b22222"
          onClick={() => props.setEdit(false)}
          variant="light"
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}
