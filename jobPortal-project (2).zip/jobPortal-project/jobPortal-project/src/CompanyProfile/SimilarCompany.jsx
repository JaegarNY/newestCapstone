import { similar } from "../Data/Company";
import CompanyCard from "./CompanyCard";

export default function SimilarCompany() {
  return (
    <div className="text-mine-shaft-100 w-1/4">
      <div className="text-xl font-semibold mb-5 ">Similar Companies</div>
      <div className="flex flex-col flex-wrap gap-3">
        {similar.map((company, index) => (
          <CompanyCard key={index} {...company} />
        ))}
      </div>
    </div>
  );
}
