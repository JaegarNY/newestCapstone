import JobCard from "../components/FindJob/JobCard";
import { jobList } from "../Data/JobData";

export default function CompanyJobs() {
  return (
    <div className="flex flex-wrap gap-5 justify-around ">
      {jobList.map((job, index) => (
        <JobCard key={index} {...job} />
      ))}
    </div>
  );
}
