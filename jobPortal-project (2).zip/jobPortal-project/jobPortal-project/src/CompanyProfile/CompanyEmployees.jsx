import TalentCard from "../components/FindTalent/TalentCard";
import { talents } from "../Data/TalentData";

export default function CompanyEmployees() {
  return (
    <div className="flex mt-10 flex-wrap gap-10 justify-around">
      {talents.map(
        (talent, index) => index < 6 && <TalentCard key={index} {...talent} />
      )}
    </div>
  );
}
