import { Avatar, Button, Tabs } from "@mantine/core";
import { Divider } from "@mantine/core";
import banner from "../assets/banner.jpg";
import avatar from "../assets/avatar.png";
import AboutCompany from "./AboutCompany";
import CompanyJobs from "./CompanyJobs";
import CompanyEmployees from "./CompanyEmployees";
export default function Company() {
  return (
    <div className="w-3/4">
      <div className="relative">
        <img className="rounded-t- w-full h-48" src={banner} alt="" />
        <img
          className="rounded-3xl w20 h-20 bottom-2/4 left-5 border-mine-shaft-950 border-8 p-2 absolute"
          src="/Companies/Google.png"
          alt=""
        />
      </div>
      <div className="px-3 text-mine-shaft-100 mt-12">
        <div className="text-3xl font-semibold flex justify-between">
          Google
          <Avatar.Group>
            <Avatar src="/Companies/avatar.png" />
            <Avatar src="/Companies/avatar.png" />
            <Avatar src="/Companies/avatar.png" />
            <Avatar>+10K</Avatar>
          </Avatar.Group>
        </div>

        <div className="flex gap-1 text-xs text-mine-shaft-400 items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-map-pin"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M9 11a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" />
            <path d="M17.657 16.657l-4.243 4.243a2 2 0 0 1 -2.827 0l-4.244 -4.243a8 8 0 1 1 11.314 0z" />
          </svg>
          US
        </div>
        <Divider my="xl" />
        <div>
          <Tabs variant="outline" radius="lg" defaultValue="about">
            <Tabs.List className="[&_button]:!text-lg font-semibold [&_button[data-active='true']]:text-bright-sun-400">
              <Tabs.Tab value="about">About </Tabs.Tab>
              <Tabs.Tab value="Jobs">Jobs </Tabs.Tab>
              <Tabs.Tab value="employees">Employees </Tabs.Tab>
            </Tabs.List>
            <Tabs.Panel value="about">
              <AboutCompany />
            </Tabs.Panel>
            <Tabs.Panel value="Jobs">
              <CompanyJobs />
            </Tabs.Panel>
            <Tabs.Panel value="employees">
              <CompanyEmployees />
            </Tabs.Panel>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
