const signupValidation=(name, value)=>{
    switch(name){
        case "name":
            if(value.length===0) return "Name is required.";
            return "";
        
        case "email":
            if(value.length===0) return "Email is required.";
            if(!/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(value)) return "Invalid email address.";
            return "";
        
        case "password":
            if(value.length===0) return "Password is required.";
            if(!/^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&+=])(?=\S+$).{8,15}$/.test(value)) 
                return "Password must be 8-15 characters long and include at least one number, one uppercase letter, one lowercase letter, and one special character.";
            return "";
        default: 
            return "";
    }
}
const loginValidation = (name, value)=>{
    switch(name){
        case "email":
            if(value.length===0) return "Email is required.";
            return "";
        
        case "password":
            if(value.length===0) return "Password is required.";
            return "";
        default: 
            return "";
    }
}

export{signupValidation, loginValidation};