import axios from "axios"

const base_url =  "http://localhost:8000";

const registerUser = async (user) =>{
    return axios.post(`${base_url}/users/register`, user).then(res=>res.data).catch(error=>{throw error;});
}

const loginUser = async (login) =>{
    return axios.post(`${base_url}/users/login`, login).then(res=>res.data).catch(error=>{throw error;});
}

const sendOtp = async (email) =>{
    return axios.post(`${base_url}/users/sendOTP/${email}`).then(res=>res.data).catch(error=>{throw error;});
}

const verifyOtp = async (email,otp) =>{
    return axios.get(`${base_url}/users/verifyOTP/${email}/${otp}`).then(res=>res.data).catch(error=>{throw error;});
}

const changePassword=async(email,password)=>{
    return axios.post(`${base_url}/users/changePass`,{email,password}).then(res=>res.data).catch(error=>{throw error;});
}

export {registerUser, loginUser, sendOtp, verifyOtp, changePassword};  