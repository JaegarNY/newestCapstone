import { notifications } from "@mantine/notifications";

const successNoti = ({title, message}) =>
{
  notifications.show({
    title: title,
    message: message,
    withCloseButton: true,
    color: "blue",
    withBorder: true,
    className: "!border-blue-900",
  });
}

const errorNoti = ({title, message}) =>
{
  notifications.show({
    title: title,
    message: message,
    withCloseButton: true,
    color: "red",
    withBorder: true,
    className: "!border-red-900",
  });
}

export { successNoti, errorNoti };