import { RichTextEditor } from "@mantine/tiptap";
import { useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Subscript from "@tiptap/extension-subscript";
import Superscript from "@tiptap/extension-superscript";
import TextAlign from "@tiptap/extension-text-align";
import Highlight from "@tiptap/extension-highlight";
import Link from "@tiptap/extension-link";
import Underline from "@tiptap/extension-underline";
import { content } from "../Data/PostJob";
export default function TextEditor() {
  const initialContent = `
  <h2>Welcome to TipTap Editor!</h2>
  <p>
    This is a rich text editor built with <strong>TipTap</strong>. You can format your text, add images, create lists, and more!
  </p>
  <h3>Features:</h3>
  <ul>
    <li><strong>Bold</strong>, <em>Italic</em>, <u>Underline</u> text formatting</li>
    <li>Create <a href="https://tiptap.dev/" target="_blank">hyperlinks</a></li>
    <li>Insert images and customize styles</li>
    <li>Create ordered and unordered lists</li>
  </ul>
  <blockquote>
    TipTap is highly customizable and developer-friendly.
  </blockquote>
  <p>
    Here's an example image:
  </p>
  <p>Start editing to see how it works!</p>
`;

  const editor = useEditor({
    extensions: [
      StarterKit,
      Underline,
      Link,
      Subscript,
      Superscript,
      Highlight,
      TextAlign.configure({ types: ["heading", "paragraph"] }),
    ],
    content,
  });
  return (
    <RichTextEditor editor={editor}>
      <RichTextEditor.Toolbar sticky stickyOffset={60}>
        <RichTextEditor.ControlsGroup>
          <RichTextEditor.Bold />
          <RichTextEditor.Italic />
          <RichTextEditor.Underline />
          <RichTextEditor.Strikethrough />
          <RichTextEditor.ClearFormatting />
          <RichTextEditor.Highlight />
          <RichTextEditor.Code />
        </RichTextEditor.ControlsGroup>
        <RichTextEditor.ControlsGroup>
          <RichTextEditor.H4 />
        </RichTextEditor.ControlsGroup>
        <RichTextEditor.ControlsGroup>
          <RichTextEditor.Blockquote />
          <RichTextEditor.OrderedList />
          <RichTextEditor.BulletList />
          <RichTextEditor.Subscript />
          <RichTextEditor.Superscript />
        </RichTextEditor.ControlsGroup>
        <RichTextEditor.ControlsGroup>
          <RichTextEditor.Link />
          <RichTextEditor.Unlink />
        </RichTextEditor.ControlsGroup>
        <RichTextEditor.ControlsGroup>
          <RichTextEditor.AlignCenter />
          <RichTextEditor.AlignJustify />
          <RichTextEditor.AlignLeft />
          <RichTextEditor.AlignRight />
        </RichTextEditor.ControlsGroup>
        <RichTextEditor.ControlsGroup>
          <RichTextEditor.Undo />
          <RichTextEditor.Redo />
        </RichTextEditor.ControlsGroup>
      </RichTextEditor.Toolbar>
      <RichTextEditor.Content />
    </RichTextEditor>
  );
}
