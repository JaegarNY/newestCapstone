import Home from "./Pages/Home";
import "@mantine/tiptap/styles.css";
import '@mantine/notifications/styles.css';
import { createTheme } from "@mui/material/styles";
import FindJobs from "./Pages/FindJobs";
import Header from "./components/Header";
import Footer from "./components/Footer";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { MantineProvider } from "@mantine/core";
import FindTalentPage from "./Pages/FindTalentPage";
import TalentProfilePage from "./Pages/TalentProfilePage";
import PostJobPage from "./Pages/PostJobPage";
import { Divider } from "@mantine/core";
import "@mantine/dates/styles.css";
import "@mantine/core/styles.css";
import "@mantine/carousel/styles.css";
import JobDescPage from "./Pages/JobDescPage";
import ApplyJobPage from "./Pages/ApplyJobPage";
import CompanyPage from "./Pages/CompanyPage";
import PostedJobPage from "./Pages/PostedJobPage";
import JobHistoryPage from "./Pages/JobHistoryPage";
import SignUpPage from "./Pages/SignUpPage";
import ProfilePage from "./Pages/ProfilePage";
import { Notifications } from "@mantine/notifications";
import Store from "./Store";
import { Provider } from "react-redux";
import { getItem } from "./Services/LocalServiceStorage";
import AppRoutes from "./Pages/AppRoutes";
function App() {
  return (
    
    <Provider store={Store}>
    <MantineProvider>
      <Notifications position="top-center" zIndex={1000}/>
      <AppRoutes />
    </MantineProvider>
    </Provider>
  );
}

export default App;
