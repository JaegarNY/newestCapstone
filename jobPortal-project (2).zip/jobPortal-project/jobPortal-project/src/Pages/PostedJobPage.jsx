import { Divider } from "@mantine/core";
import PostedJob from "../PostedJobs/PostedJob";
import PostedJobDesc from "../PostedJobs/PostedJobDesc";

export default function PostedJobPage() {
  return (
    <div className="min-h-[100vh] bg-mine-shaft-950 p-4">
      <div className="flex gap-5 ">
        <PostedJob />
        <PostedJobDesc />
      </div>
    </div>
  );
}
