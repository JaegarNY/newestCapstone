import Jobs from "../components/FindJob/Jobs";
import SearchBar from "../components/FindJob/SearchBar";
import { Divider } from "@mantine/core";
export default function FindJobs() {
  return (
    <div className="min-h-[100vh] bg-mine-shaft-950">
      <SearchBar />
      <Divider size="xs" mx="md" />
      <Jobs />
    </div>
  );
}
