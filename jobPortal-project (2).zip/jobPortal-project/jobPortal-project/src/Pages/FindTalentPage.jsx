import { Divider } from "@mantine/core";
import SearchBar from "../components/FindTalent/SearchBar";
import TalentCard from "../components/FindTalent/TalentCard";
import Talents from "../components/FindTalent/Talents";
export default function FindTalentPage() {
  return (
    <div className="min-h-[100vh] bg-mine-shaft-950">
      <SearchBar />
      <Divider size="xs" mx="md" />
      <Talents />
    </div>
  );
}
