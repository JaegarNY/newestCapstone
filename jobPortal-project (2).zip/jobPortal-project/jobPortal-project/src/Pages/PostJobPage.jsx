import { Divider } from "@mantine/core";
import PostJob from "../PostJob/PostJob";

export default function PostJobPage() {
  return (
    <div className="min-h-[100vh] bg-mine-shaft-950 p-4">
      <PostJob />
    </div>
  );
}
