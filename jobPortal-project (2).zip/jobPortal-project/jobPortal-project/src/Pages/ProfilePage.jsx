import Profile from "../Profile/Profile";

export default function ProfilePage() {
  return (
    <div className="min-h[90vh] bg-mine-shaft-950">
      <Profile />
    </div>
  );
}
