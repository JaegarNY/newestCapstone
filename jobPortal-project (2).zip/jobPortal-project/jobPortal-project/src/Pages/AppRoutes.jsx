import Home from "./Home";
import "@mantine/tiptap/styles.css";
import '@mantine/notifications/styles.css';
import { createTheme } from "@mui/material/styles";
import FindJobs from "./FindJobs";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { MantineProvider } from "@mantine/core";
import FindTalentPage from "./FindTalentPage";
import TalentProfilePage from "./TalentProfilePage";
import PostJobPage from "./PostJobPage";
import { Divider } from "@mantine/core";
import "@mantine/dates/styles.css";
import "@mantine/core/styles.css";
import "@mantine/carousel/styles.css";
import JobDescPage from "./JobDescPage";
import ApplyJobPage from "./ApplyJobPage";
import CompanyPage from "./CompanyPage";
import PostedJobPage from "./PostedJobPage";
import JobHistoryPage from "./JobHistoryPage";
import SignUpPage from "./SignUpPage";
import ProfilePage from "./ProfilePage";
import { useSelector } from "react-redux";

const AppRoutes = () =>{
    const user= useSelector((state)=>state.user);
    return <BrowserRouter>
        <div className="relative">
          <Header />
          <Divider size="xs" mx="md" />
          <Routes>
            <Route path="/job-history" element={<JobHistoryPage />} />
            <Route path="/company" element={<CompanyPage />} />
            <Route path="/posted-job" element={<PostedJobPage />} />
            <Route path="/find-jobs" element={<FindJobs />} />
            <Route path="*" element={<Home />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/apply-job" element={<ApplyJobPage />} />
            <Route path="/jobs" element={<JobDescPage />} />
            <Route path="/signup" element={user?<Navigate to = "/"/>:<SignUpPage />} />
            <Route path="/login" element={user?<Navigate to = "/"/>:<SignUpPage />} />
            <Route path="/post-jobs" element={<PostJobPage />} />
            <Route path="/talent-profile" element={<TalentProfilePage />} />
            <Route path="/find-talent" element={<FindTalentPage />} />
          </Routes>
          <Footer />
        </div>
      </BrowserRouter>
}
export default AppRoutes;