import Companies from "../components/Companies";
import DreamJob from "../components/DreamJob";
import Footer from "../components/Footer";
import Header from "../components/Header";
import JobCategory from "../components/JobCategory";
import JobUpdate from "../components/JobUpdate";
import Subscribe from "../components/Subscribe";
import Testimonials from "../components/Testimonials";
import Working from "../components/Working";

export default function Home() {
  return (
    <div className="min-h-[100vh] bg-mine-shaft-950">
      <DreamJob />
      <Companies />
      <JobCategory />
      <Working />
      <Testimonials />
      <Subscribe />
    </div>
  );
}