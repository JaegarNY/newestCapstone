import React, { useState } from "react";
import { Modal, TextInput, Button, PinInput } from "@mantine/core";
import { changePassword, sendOtp, verifyOtp } from "../Services/UserService";
import { signupValidation } from "../Services/FormValidation";
import { successNoti,errorNoti } from "../Services/NotificationServices";
import { PasswordInput } from "@mantine/core";
import { useInterval } from "@mantine/hooks";

const ResetPassword = (props) => {
  const [email, setEmail] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [verified, setVerified] = useState(false);
  const [password, setPassword] = useState("");
  const [passErr, setPassErr] = useState("");
  const [otpSending, setOtpSending] = useState(false);
  const [resendLoader, setResendLoader] = useState(false);
  const [seconds, setSeconds] = useState(60);
  const interval = useInterval(()=> {
    if(seconds === 0){
      setResendLoader(false);
      setSeconds(60);
      interval.stop();
    } else
    setSeconds((s)=>s-1)},1000);

  const handleSendOtp = () => {
    setOtpSending(true);
    sendOtp(email)
      .then((res) => {
        console.log(res);
        successNoti({ title: "OTP Sent", message: "Enter OTP to reset password" });
        setOtpSent(true);
        setOtpSending(false);
        setResendLoader(true)
        interval.start();
      })
      .catch((err) => {
        console.log(err);
        errorNoti({ title: "OTP Failed", message: err.response.data.errorMessage });
      });
  };

  const handleVerifyOtp = (otp) => {
    verifyOtp(email, otp).then((res) => {
      console.log(res);
      successNoti({ title: "OTP Verified Successfully", message: "Enter new password" });
      setVerified(true);
    }).catch((err) => {
      console.log(err);
      errorNoti({ title: "OTP Verification Failed", message: err.response.data.errorMessage });
    });
  }

  const resendOtp = () => {
    if(resendLoader) return;
    handleSendOtp();
  }

  const changeEmail = () => {
    setOtpSent(false);
    setResendLoader(false);
    setSeconds(60);
    setVerified(false);
    interval.stop();
  }

  const handleResetPassword = () => {
    changePassword(email, password).then((res) => {
      console.log(res);
      successNoti({ title: "Password Changed Successfully", message: "You can now login with new password" });
      props.close();
    }).catch((err) => {
      console.log(err);
      errorNoti({ title: "Password Change Failed", message: err.response.data.errorMessage });
    });
  }
  return (
    <Modal
      opened={props.opened}
      onClose={props.close}
      title="Reset Password"
      size="md"
      styles={{
        modal: {
          padding: '20px',
          backgroundColor: '#6d6d6d',
        },
        title: {
          fontSize: '24px',
          fontWeight: 'bold',
        },
        body: {
          display: 'flex',
          flexDirection: 'column',
          gap: '20px',
        },
      }}
    >
      <div style={{ textAlign: 'center' }}>
        <TextInput
          withAsterisk
          leftSection={
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="20"
              height="20"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="icon icon-tabler icons-tabler-outline icon-tabler-at"
            >
            </svg>
          }
          placeholder="Enter your email"
          value={email}
          onChange={(event) => setEmail(event.currentTarget.value)}
          styles={{
            input: {
              padding: '10px',
              fontSize: '16px',
            },
          }}
        />
        <Button loading={otpSending} onClick={handleSendOtp} style={{ backgroundColor: "#6d6d6d", color: "white", padding: "10px 20px", border: "none", borderRadius: "5px", cursor: "pointer", marginTop: "20px", marginLeft: "140px",  display: otpSent ? "none" : "block"  }} >
          Send OTP
        </Button>
        {otpSent && (
          <PinInput
            length={6}
            className="mx-auto"
            type="number"
            onComplete={handleVerifyOtp}
            style={{ marginTop: '20px', display: 'flex', justifyContent: 'center' }}
          />
        )}
        {otpSent && !verified &&
         <div className="flex gap-2">
          <button onClick={resendOtp} loading={otpSending}
           style={{ backgroundColor: "#6d6d6d", color: "white", padding: "10px 10px", border: "none", borderRadius: "5px", cursor: "pointer", marginTop: "20px", marginLeft: "90px" }}>
            {resendLoader?seconds:"Resend"}</button>
          
          <button onClick={changeEmail}  style={{ backgroundColor: "#5d5d5d", color: "white", padding: "10px 20px", border: "none", borderRadius: "5px", cursor: "pointer", marginTop: "20px", marginLeft: "30px"}}>Change Email</button>
          </div>}
          {verified && <PasswordInput
                  withAsterisk
                  leftSection={
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="24"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="icon icon-tabler icons-tabler-outline icon-tabler-lock"
                    >
                      <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                      <path d="M5 13a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-6z" />
                      <path d="M11 16a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" />
                      <path d="M8 11v-4a4 4 0 1 1 8 0v4" />
                    </svg>
                  }
                  value={password}
                  name="password"
                  error={passErr}
                  onChange={(e)=>{setPassword(e.target.value); setPassErr(signupValidation("password",e.target.value));}}
                  label="Password"
                  placeholder="Password"
                />}
                {verified && 
                <Button onClick={handleResetPassword} autoContrast variant="filled"
                 color="#ffd149">
                  Change Password</Button>}
      </div>
    </Modal>
  );
};

export default ResetPassword;