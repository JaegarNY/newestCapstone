import { Button, PasswordInput, TextInput } from "@mantine/core";
import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { loginUser } from "../Services/UserService";
import { loginValidation } from "../Services/FormValidation";
import { notifications } from "@mantine/notifications";
import { useDisclosure } from "@mantine/hooks";
import ResetPassword from "./ResetPassword";
import { useDispatch } from "react-redux";
import { setUser } from "../Slices/UserSlice";
import { LoadingOverlay } from "@mantine/core";
const form = {
  email: "",
  password: "",
};

export default function Login() {
  const dispatch = useDispatch();
  const [data, setData] = useState(form);
  const [formError, setFormError] = useState(form);
  const navigate = useNavigate();
  const [opened, { open, close }] = useDisclosure(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    
    let valid = true;
    let newFormError = {};

    for (let key in data) {
      newFormError[key] = loginValidation(key, data[key]);
      if (newFormError[key]) valid = false;
    }

    setFormError(newFormError);

    if (valid) {
      setLoading(true);
      loginUser(data)
        .then((res) => {
          console.log(res);
          setData(form);
          notifications.show({
            title: "Log in Successfully",
            message: "Redirecting to home page...",
            withCloseButton: true,
            color: "blue",
            withBorder: true,
            className: "!border-blue-900",
          });

          setTimeout(() => {
            setLoading(false);
            dispatch(setUser(res));
            navigate("/");
          }, 4000);
        })
        .catch((err) => {
          setLoading(false);
          console.log(err);
          notifications.show({
            title: "Log in Failed",
            message: err.response?.data?.errorMessage || "Login failed",
            withCloseButton: true,
            color: "red",
            withBorder: true,
            className: "!border-red-900",
          });
        });
    }
  };

  return (
    <>
      <LoadingOverlay
          visible={loading}
          zIndex={1000}
          overlayProps={{ radius: 'sm', blur: 1 }}
          loaderProps={{ color: '#f99b07', type: 'bars' }}
        />
    <div className="w-1/2 text-mine-shaft-100 px-20 flex flex-col justify-center gap-3">
      <div className="text-2xl font-semibold">Log In</div>

      <TextInput
        withAsterisk
        leftSection={
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-at"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0" />
            <path d="M16 12v1.5a2.5 2.5 0 0 0 5 0v-1.5a9 9 0 1 0 -5.5 8.28" />
          </svg>
        }
        value={data.email}
        name="email"
        error={formError.email}
        onChange={handleChange}
        label="Email"
        placeholder="Your email"
      />

      <PasswordInput
        withAsterisk
        leftSection={
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-lock"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M5 13a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-6z" />
            <path d="M11 16a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" />
            <path d="M8 11v-4a4 4 0 1 1 8 0v4" />
          </svg>
        }
        value={data.password}
        name="password"
        error={formError.password}
        onChange={handleChange}
        label="Password"
        placeholder="Password"
      />

      <Button loading={loading} onClick={handleSubmit} autoContrast variant="filled" color="#ffd149">
        Log In
      </Button>

      <div className="mx-auto">
        Don't have an account?
        <span
          className="text-bright-sun-400 hover:underline cursor-pointer"
          onClick={() => {
            navigate("/signup");
            setFormError(form);
            setData(form);
          }}
        >
          Sign Up
        </span>

        <div onClick={open} className="text-bright-sun-400 hover:underline cursor-pointer text-center">
          Forgot Password?
        </div>
      </div>
      <ResetPassword opened={opened} close={close} />
    </div>
    </>
  );
}

