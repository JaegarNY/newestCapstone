import { Button, Checkbox, PasswordInput, TextInput,Radio, Group, em } from "@mantine/core";
import { Link } from "react-router-dom";

import { useState } from "react";
import { registerUser } from "../Services/UserService";
import { signupValidation } from "../Services/FormValidation";
import { notifications } from "@mantine/notifications";
import { useNavigate } from "react-router-dom";
import { LoadingOverlay } from "@mantine/core";

const form= {
  name:"",
  email:"",
  password:"",
  confirmPassword:"",
  accountType:"APPLICANT",  
}
export default function SignUp() {
  const [value, setValue] = useState('react');

  const [data, setData] = useState(form);
  const[loading,setLoading]=useState(false);
  const navigate = useNavigate();
  const [formError, setFormError] = useState(form);

  const handleChange = (e) => {
    if(typeof (e) == "string"){
      setData({...data,accountType:e});
      return;
    }
    let name=e.target.name, value=e.target.value;
    setData({...data,[name]:value});
    setFormError({...formError,[name]:signupValidation(name,value)})

    if(name=="password" && data.confirmPassword!==""){
      let err="";
      if(data.confirmPassword!==value) err="Password does not match";
      setFormError({...formError,[name]:signupValidation(name,value), confirmPassword:err})
    }
    if(name === "confirmPassword"){
      if(data.password !== value) setFormError({...formError,[name]:"Password does not match"});
      else setFormError({...formError,confirmPassword:""})
    }
  }

  const handleSubmit = () =>{
    
    let valid = true, newFormError = {};
    for(let key in data){
      if(key==="accountType") continue;
      if(key !== "confirmPassword") newFormError[key] = signupValidation(key,data[key]);
      else if(data[key] !== data["password"]) newFormError[key] = "Password does not match";
      if(newFormError[key])valid = false; 
    }
    setFormError(newFormError);
    if(valid === true){
      setLoading(true);
      registerUser(data).then((res)=>{
        console.log(res);
        setData(form);
        notifications.show({
          title: 'Registered Successfully',
          message: 'Redirecting to login page...',
          withCloseButton: true,
          color:"blue",
          withBorder: true,
          className: "!border-blue-900"
        })
        setTimeout(()=>{
          setLoading(false);
          navigate("/login");
        },4000)

    })
    .catch((err) => {
      setLoading(false);
      console.log(err);
      notifications.show({
        title: 'Registration Failed',
        message: err.response.data.errorMessage,
        withCloseButton: true,
        color: "red",
        withBorder: true,
        className: "!border-red-900",
      });
    });
}
};

  return (
    <>
          <LoadingOverlay
              visible={loading}
              zIndex={1000}
              className="translate-x-1/2"
              overlayProps={{ radius: 'sm', blur: 1 }}
              loaderProps={{ color: '#f99b07', type: 'bars' }}
            />
    <div className="w-1/2 text-mine-shaft-100 px-20 flex flex-col justify-center gap-3">
      <div className="text-2xl font-semibold">Create Account</div>
      <TextInput value={data.name} error={formError.name} name="name" onChange={handleChange} withAsterisk label="Full Name" placeholder="Your name" />
      <TextInput
        withAsterisk
        leftSection={
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-at"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0" />
            <path d="M16 12v1.5a2.5 2.5 0 0 0 5 0v-1.5a9 9 0 1 0 -5.5 8.28" />
          </svg>
        }
        value={data.email}
        error={formError.email}
        name="email"
        onChange={handleChange}
        label="Email"
        placeholder="Your email"
      />
      <PasswordInput
        withAsterisk
        leftSection={
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-lock"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M5 13a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-6z" />
            <path d="M11 16a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" />
            <path d="M8 11v-4a4 4 0 1 1 8 0v4" />
          </svg>
        }
        value={data.password}
        error={formError.password}
        name="password"
        onChange={handleChange}
        label="Password"
        placeholder="Password"
      />
      <PasswordInput
        withAsterisk
        leftSection={
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-lock"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M5 13a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-6z" />
            <path d="M11 16a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" />
            <path d="M8 11v-4a4 4 0 1 1 8 0v4" />
          </svg>
        }
        value={data.confirmPassword}
        error={formError.confirmPassword}
        name="confirmPassword"
        onChange={handleChange}
        label="Confirm Password"
        placeholder="Confirm Password"
      />
         <Radio.Group
      value={data.accountType}
      onChange={handleChange}
      label="You are"
      withAsterisk
    >
      <Group mt="xs">
      <Radio className="py-4 px-6 border hover:bg-mine-shaft-900 has-[:checked]:bg-bright-sun-400/5 has-[:checked]:border-bright-sun-400 border-mine-shaft-800 rounded-lg" value="APPLICANT" label="Applicant" />
      <Radio className="py-4 px-6 border hover:bg-mine-shaft-900 has-[:checked]:bg-bright-sun-400/5 has-[:checked]:border-bright-sun-400 border-mine-shaft-800 rounded-lg"  value="EMPLOYER" label="Employer" /> 
      </Group>
    </Radio.Group>
      

      <Checkbox
        color="#ffd149"
        autoContrast
        label={
          <>
            I accept{" "}
            <span className="text-bright-sun-300">terms & conditions</span>
          </>
        }
      />
      <Button loading={loading} onClick={handleSubmit}autoContrast variant="filled" color="#ffd149">
        Sign up
      </Button>
      <div className="mx-auto">
        Have an account?
        <span className="text-bright-sun-400 hover:underline cursor-pointer" onClick={() => { navigate("/login"); setFormError("form"); setData(form); }}>
          Login
        </span>
      </div>
    </div>
    </>
  );
}
