import banner from "../../assets/banner.jpg";
import avatar from "../../assets/avatar.png";
import { Button } from "@mantine/core";
import { Divider } from "@mantine/core";
import ExpCard from "./ExpCard";
import Certificate from "./Certificate";
export default function TalentProfile(props) {
  return (
    <div className="w-2/3">
      <div className="relative">
        <img className="rounded-t-2xl w-full h-40" src={banner} alt="" />
        <img
          className="rounded-full w-24 h-24 bottom-1/4 left-3 border-mine-shaft-950 border-8 absolute"
          src={avatar}
          alt=""
        />
      </div>
      <div className="px-3 text-mine-shaft-100 mt-3">
        <div className="text-3xl font-semibold flex justify-between">
          {props.name}
          <Button color="#ffbd20" variant="light">
            Message
          </Button>
        </div>
        <div className="text-xl flex gap-1 items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-briefcase  p-1 bg-mine-shaft-900 rounded-full mr-2"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M3 7m0 2a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v9a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2z" />
            <path d="M8 7v-2a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v2" />
            <path d="M12 12l0 .01" />
            <path d="M3 13a20 20 0 0 0 18 0" />
          </svg>{" "}
          {props.role} &bull; {props.company}
        </div>
        <div className="flex gap-1 text-xs text-mine-shaft-400 items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-map-pin"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M9 11a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" />
            <path d="M17.657 16.657l-4.243 4.243a2 2 0 0 1 -2.827 0l-4.244 -4.243a8 8 0 1 1 11.314 0z" />
          </svg>
          {props.location}
        </div>
      </div>

      <Divider mx="xs" my="xl" />
      <div className="text-mine-shaft-300 px-3">
        <div className="text-2xl font-semibold mb-3">About</div>
        <div className="text-sm text-justify ">{props.about}</div>
      </div>
      <Divider mx="xs" my="xl" />
      <div className="text-mine-shaft-300 px-3">
        <div className="text-2xl font-semibold mb-3">Skill</div>
        <div className="flex flex-wrap gap-2">
          {props.skills.map((skill, index) => (
            <div
              key={index}
              className="bg-bright-sun-300 text-sm font-medium bg-opacity-15 rounded-3xl text-bright-sun-400 px-3 py-1"
            >
              {skill}
            </div>
          ))}
        </div>
      </div>
      <Divider mx="xs" my="xl" />
      <div className="text-mine-shaft-300 px-3">
        <div className="text-2xl font-semibold mb-5">Experience</div>
        <div className="flex flex-col gap-8">
          {props.experience.map((exp, index) => (
            <ExpCard key={index} {...exp} />
          ))}
        </div>
      </div>
      <Divider mx="xs" my="xl" />
      <div className="text-mine-shaft-300 px-3">
        <div className="text-2xl font-semibold mb-5">Certification</div>
        <div className="flex flex-col gap-8">
          {props.certifications.map((cer, index) => (
            <Certificate key={index} {...cer} />
          ))}
        </div>
      </div>
    </div>
  );
}
