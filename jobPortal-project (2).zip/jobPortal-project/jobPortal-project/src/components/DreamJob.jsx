import Working from "../assets/images.jpg";
import PA1 from "../assets/pa1.jpg";
import PA2 from "../assets/pa2.jpg";
import PA3 from "../assets/pa3.jpg";
import PA4 from "../assets/pa4.png";
import Google from "../assets/google.png";
import { TextInput } from "@mantine/core";

import { FaSearch } from "react-icons/fa";
export default function DreamJob() {
  return (
    <div className="flex items-center p-16">
      <div className="flex flex-col w-[45%] gap-3">
        <div className="text-6xl font-bold leading-tight text-mine-shaft-100">
          Find your <span className="text-bright-sun-400">dream</span>{" "}
          <span className="text-bright-sun-400">job</span> with us
        </div>
        <div className="text-lg text-mine-shaft-200">
          Good life begins with a good company. Start exokire thousands of jobs
          in one place
        </div>
        <div className="flex gap-3 items-center mt-5">
          <TextInput
            className="bg-mine-shaft-900 rounded-lg p-1 px-2 text-mine-shaft-100 [&_input]:!text-mine-shaft-100 "
            variant="unstyled"
            label="Job Title"
            placeholder="Software Engineer"
          />
          <TextInput
            className="bg-mine-shaft-900 rounded-lg p-1 px-2 text-mine-shaft-100 [&_input]:!text-mine-shaft-100"
            variant="unstyled"
            label="Job Type"
            placeholder="Fulltime"
          />
          <div className="bg-bright-sun-300 items-center h-full w-20 rounded-lg hover:bg-bright-sun-500 cursor-pointer">
            <FaSearch className="h-[85%] w-[85%]" />
            {/*<div className="items-center p-2"> 
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="30"
              height="30"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="icon icon-tabler icons-tabler-outline icon-tabler-search "
            >
              <path stroke="none" d="M0 0h24v24H0z" fill="none" />
              <path d="M10 10m-7 0a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" />
              <path d="M21 21l-6 -6" />
            </svg>
             </div>*/}
          </div>
        </div>
      </div>
      <div className="w-[55%] flex items-center justify-center">
        <div className="w-[30rem] relative">
          <img className="w-full" src={Working} alt="" />
          <div className="absolute right-1 w-fit border-bright-sun-400 border top-[70%] rounded-lg p-2 backdrop-blur-md">
            <div className="text-center mb-1 text-sm text-mine-shaft-100">
              10K+ got job
            </div>
            <div className="flex">
              <img src={PA1} alt="" className="w-7 h-7 rounded-full " />
              <img src={PA2} alt="" className="w-7 h-7 rounded-full info " />
              <img src={PA3} alt="" className="w-7 h-7 rounded-full info" />
              <img src={PA4} alt="" className="w-7 h-7 rounded-full info" />
            </div>
          </div>
          <div className="absolute left-5 w-fit border-bright-sun-400 border top-[18%] rounded-lg p-2 backdrop-blur-md gap-3 flex flex-col">
            <div className="flex gap-2 items-center">
              <div className="w-10 h-10 p-1 bg-mine-shaft-900 rounded-lg">
                <img src={Google} alt="" />{" "}
              </div>
              <div className="text-sm text-mine-shaft-100">
                <div>Software Engineer</div>
                <div className="text-mine-shaft-100">New York</div>
              </div>
            </div>
            <div className="flex gap-2 justify-around text-mine-shaft-200 text-xs">
              <span>1 day ago</span>
              <span>120 Applicants</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
