import JobCard from "./JobCard";
import Sort from "./Sort";
import { jobList } from "../../Data/JobData";
export default function Jobs() {
  return (
    <div className="p-5">
      <div className="text-mine-shaft-200 flex justify-between">
        <div className="text-2xl font-semibold">Recommended Jobs</div>

        <Sort />
      </div>
      <div className="flex flex-wrap mt-10 gap-5 justify-around">
        {jobList.map((job, index) => (
          <JobCard key={index} {...job} />
        ))}
      </div>
    </div>
  );
}
