import { Carousel } from "@mantine/carousel";
import { jobCategory } from "../Data/Data";
import Marquee from "react-fast-marquee";
import JobUpdate from "./JobUpdate";
export default function JobCategory() {
  return (
    <div className="mt-20 pb-5">
      <div className="text-4xl text-center mb-3 font-semibold text-mine-shaft-100">
        Browse<span className="text-bright-sun-400">Job</span> Categories
      </div>
      <div className="text-lg mb-10 mx-auto text-mine-shaft-300 text-center w-1/2">
        Explore diverse job opportunities tailored to your skills. Start your
        career journey today!
      </div>
      <JobUpdate />
    </div>
  );
}
