import { ActionIcon, Button } from "@mantine/core";
import { Link } from "react-router-dom";
import { Divider } from "@mantine/core";
import DOMPurify from "dompurify";
import { card, desc, skills } from "../../Data/JobDescData";
export default function JobDes(props) {
  const data = desc;
  return (
    <div className="w-2/3">
      <div className="flex justify-between">
        <div className="flex gap-2 items-center">
          <div className="p-3 bg-mine-shaft-800 rounded-xl">
            <img className="h-10" src={`/Companies/Google.png`} alt="" />
          </div>
          <div className="flex flex-col gap-1">
            <div className="font-semibold text-2xl text-mine-shaft-100">
              Software Engineer
            </div>
            <div className="text-xs text-mine-shaft-300">
              Google &#x2022; 3 days ago &#x2022; 48 applications
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-2 items-center">
          <Link to="/apply-job">
            <Button size="sm" color="#ffbd20" variant="light">
              {props.edit ? "Edit" : "Apply"}
            </Button>
          </Link>
          {props.edit ? (
            <Button size="sm" color="#b22222" variant="outline">
              Delete
            </Button>
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="icon icon-tabler icons-tabler-outline icon-tabler-bookmark text-bright-sun-400 cursor-pointer"
            >
              <path stroke="none" d="M0 0h24v24H0z" fill="none" />
              <path d="M18 7v14l-6 -4l-6 4v-14a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4z" />
            </svg>
          )}
        </div>
      </div>
      <Divider my="xl" />
      <div className="flex justify-between">
        {card.map((item, index) => (
          <div key={index} className="flex flex-col items-center  gap-1">
            {item.icon}

            <div className="text-sm text-mine-shaft-300">{item.name}</div>
            <div className="font-semibold text-mine-shaft-300">
              {item.value}
            </div>
          </div>
        ))}
      </div>
      <Divider my="xl" />
      <div>
        <div className="tet-xl font-semibold mb-5 text-mine-shaft-200">
          Required Skills
        </div>
        <div className="flex flex-wrap gap-2">
          {skills.map((skill, index) => (
            <ActionIcon
              key={index}
              color="#ffbd20"
              className="!h-fit font-medium !text-sm !w-fit"
              variant="light"
              p="xs"
              radius="xl"
              aria-label="Settings"
            >
              {skill}
            </ActionIcon>
          ))}
        </div>
        <Divider my="xl" />
        <div
          className="text-mine-shaft-200 [&_h2]:text-xl [&_li]:marker:text-bright-sun-400 [&_li]:mb-1 [&_*]:text-mine-shaft-300 [&_h2]:my-5 [&_h2]:font-semibold [&_h2]:text-mine-shaft-200 [&_p]:text-justify"
          dangerouslySetInnerHTML={{ __html: data }}
        ></div>
        <Divider my="xl" />
        <div>
          <div className="tet-xl font-semibold mb-5 text-mine-shaft-200">
            About Company
          </div>
          <div>
            {" "}
            <div className="flex justify-between mb-3">
              <div className="flex gap-2 items-center">
                <div className="p-1 bg-mine-shaft-800 <!--rounded-xl-->">
                  <img className="h-6" src={`/Companies/Google.png`} alt="" />
                </div>
                <div className="flex flex-col">
                  <div className="font-medium text-lg text-mine-shaft-100">
                    Google
                  </div>
                  <div className=" text-mine-shaft-300">10K+ Employees</div>
                </div>
              </div>
              <div className="flex flex-col gap-2 items-center">
                <Link to="/company">
                  <Button size="sm" color="#ffbd20" variant="light">
                    Company Page
                  </Button>
                </Link>
              </div>
            </div>
            <div className="text-mine-shaft-300 text-justify">
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Amet
              quos nam facilis voluptates perspiciatis non? Dignissimos unde
              mollitia delectus officia officiis, inventore, impedit ratione
              quia harum fugit et tempore? Ratione. Lorem, ipsum dolor sit amet
              consectetur adipisicing elit. Eum, corporis voluptatum sequi
              sapiente est possimus dolor culpa laborum tempora incidunt
              inventore velit sed natus nobis exercitationem tempore
              consequuntur aliquid in.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
