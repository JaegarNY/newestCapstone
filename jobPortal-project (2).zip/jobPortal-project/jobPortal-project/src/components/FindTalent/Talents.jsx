import JobCard from "../FindJob/JobCard";
import Sort from "../FindJob/Sort";
import { jobList } from "../../Data/JobData";
import TalentCard from "./TalentCard";
import { talents } from "../../Data/TalentData";
export default function Talents() {
  return (
    <div className="p-5">
      <div className="text-mine-shaft-200 flex justify-between">
        <div className="text-2xl font-semibold">Talents</div>

        <Sort />
      </div>
      <div className="flex flex-wrap mt-10 gap-3 justify-between">
        {talents.map((talent, index) => (
          <TalentCard key={index} {...talent} />
        ))}
      </div>
    </div>
  );
}
