import { Carousel } from "@mantine/carousel";
import { jobCategory } from "../Data/Data";
export default function JobUpdate() {
  return (
    <Carousel slideSize="22%" slideGap="md" loop>
      {jobCategory.map((category, index) => (
        <div key={index} className="mx-8">
          <div className="flex flex-col items-center w-64 gap-2 border border-bright-sun-400">
            <div className="p-2 bg-bright-sun-300 rounded-full mx-8">
              <img
                className="h-10 w-10 rounded-full "
                src={`/Category/${category}.jpg`}
                alt={category}
              />
            </div>
            <div className="text-mine-shaft-200 text-lg font-semibold">
              {category}
            </div>
            <div className="text-sm text-center text-mine-shaft-300">
              Lorem ipsum dolor sit amet consectetur, adipisicing elit. Pariatur
              fugit numquam necessitatibus harum consequuntur odio?
            </div>
            <div className="text-bright-sun-300 text-lg">
              1K+ new job posted
            </div>
          </div>
        </div>
      ))}
    </Carousel>
  );
}
