import { Button, Text } from "@mantine/core"; // Or the correct library
import { Divider } from "@mantine/core";
import { Link } from "react-router-dom";
export default function Card(props) {
  return (
    <Link
      to="/jobs"
      className="bg-mine-shaft-900 text-mine-shaft-300 p-4 w-72 flex flex-col gap-3 rounded-xl transition duration-300 ease-in-out"
    >
      <div className="flex justify-between">
        <div className="flex gap-2 items-center">
          <div className="p-1.5 bg-mine-shaft-800 rounded-md">
            <img
              className="h-7"
              src={`/Companies/${props.company}.png`}
              alt=""
            />
          </div>
          <div>
            <div className="font-semibold">{props.jobTitle}</div>
            <div className="text-xs text-mine-shaft-300">
              {props.company} &#x2022; {props.applicants} applications
            </div>
          </div>
        </div>
        {props.saved ? (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="currentColor"
            className="icon icon-tabler icons-tabler-filled icon-tabler-bookmark text-bright-sun-400"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M14 2a5 5 0 0 1 5 5v14a1 1 0 0 1 -1.555 .832l-5.445 -3.63l-5.444 3.63a1 1 0 0 1 -1.55 -.72l-.006 -.112v-14a5 5 0 0 1 5 -5h4z" />
          </svg>
        ) : (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-bookmark cursor-pointer"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M18 7v14l-6 -4l-6 4v-14a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4z" />
          </svg>
        )}
      </div>
      <div className="flex gap-2 [&>div]:py-1 [&>div]:px-2 [&>div]:bg-mine-shaft-800 [&>div]:text-bright-sun-400 [&>div]:rounded-lg text-xs">
        <div>{props.experience}</div>
        <div>{props.jobType}</div>
        <div>{props.location}</div>
      </div>
      <Text className="!text-xs text-justify text" lineClamp={3}>
        {props.description}
      </Text>
      <Divider size="xs" color="#4f4f4f" />
      <div className="flex justify-between">
        <div className="font-semibold text-mine-shaft-200">
          $ {props.package}
        </div>
        <div className="flex gap-1 text-xs text-mine-shaft-400 items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-clock-hour-3 h-5 w-5"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0" />
            <path d="M12 12h3.5" />
            <path d="M12 7v5" />
          </svg>
          {props.applied || props.interviewing
            ? "Applied"
            : props.offered
            ? "Interviewed"
            : "Posted"}
          {props.postedDaysAgo} days ago
        </div>
      </div>
      {(props.offered || props.interviewing) && (
        <Divider color="#4f4f4f" size="xs" />
      )}
      {props.offered && (
        <div className="flex gap-2">
          <Button color="#ffbd20" variant="outline" fullWidth>
            Accept
          </Button>
          <Button color="#ffbd20" variant="light" fullWidth>
            Reject
          </Button>
        </div>
      )}
      {props.interviewing && (
        <div className="flex gap-1 text-mine-shaft-200 text-sm items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="icon icon-tabler icons-tabler-outline icon-tabler-calendar w-5 h-5 text-bright-sun-400"
          >
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M4 7a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v12a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12z" />
            <path d="M16 3v4" />
            <path d="M8 3v4" />
            <path d="M4 11h16" />
            <path d="M11 15h1" />
            <path d="M12 15v3" />
          </svg>{" "}
          Sun, August 27 &bull;{" "}
          <pan className="text-mine-shaft-400"> 10:00 AM</pan>
        </div>
      )}
    </Link>
  );
}
