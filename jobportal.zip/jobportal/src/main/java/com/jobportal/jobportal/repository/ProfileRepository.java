package com.jobportal.jobportal.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.jobportal.jobportal.entity.Profile;

public interface ProfileRepository extends MongoRepository<Profile,Long>{

}
