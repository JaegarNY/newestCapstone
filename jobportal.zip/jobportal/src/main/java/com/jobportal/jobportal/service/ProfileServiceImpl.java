package com.jobportal.jobportal.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobportal.jobportal.dto.ProfileDTO;
import com.jobportal.jobportal.entity.Profile;
import com.jobportal.jobportal.exception.JobPortalException;
import com.jobportal.jobportal.repository.ProfileRepository;
import com.jobportal.jobportal.utility.Utilities;

@Service("ProfileService")
public class ProfileServiceImpl implements ProfileService{

    @Autowired
    private ProfileRepository profileRepository;

    @Override
    public Long createProfile(String email) throws JobPortalException {
        // TODO Auto-generated method stub
        Profile profile = new Profile();
        profile.setId(Utilities.getNextSequence("profiles"));
        profile.setEmail(email);
        profile.setSkills(new ArrayList<>());
        profile.setExperiences(new ArrayList<>());
        profile.setCertifications(new ArrayList<>());
        profileRepository.save(profile);
        return profile.getId();
    }

    @Override
    public ProfileDTO getProfile(Long id) throws JobPortalException {
        // TODO Auto-generated method stub
        return profileRepository.findById(id).orElseThrow(()-> 
        new JobPortalException("PROFILE_NOT_FOUND")).toDTO();
    }

    @Override
    public ProfileDTO updateProfile(ProfileDTO profileDTO) throws JobPortalException {
        // TODO Auto-generated method stub
        profileRepository.findById(profileDTO.getId()).orElseThrow(()-> 
        new JobPortalException("PROFILE_NOT_FOUND"));
        profileRepository.save(profileDTO.toEntity());
        return profileDTO;
    }

}
