package com.jobportal.jobportal.dto;

public enum AccountType {
    APPLICANT,
    EMPLOYER
}
