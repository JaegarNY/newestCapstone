package com.jobportal.jobportal.utility;

public class Data {
    public static String getMessageBody(String otp, String name) {
        return String.format("""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Your OTP Code</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f9f9f9;
                    margin: 0;
                    padding: 0;
                }
                .email-container {
                    max-width: 600px;
                    margin: 20px auto;
                    background-color: #ffffff;
                    border-radius: 10px;
                    overflow: hidden;
                    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
                }
                .email-header {
                    background-color: #4caf50;
                    color: #ffffff;
                    text-align: center;
                    padding: 20px;
                    font-size: 24px;
                }
                .email-body {
                    padding: 20px;
                    color: #333333;
                    font-size: 16px;
                    line-height: 1.6;
                }
                .otp {
                    font-size: 32px;
                    color: #4caf50;
                    text-align: center;
                    margin: 20px 0;
                    font-weight: bold;
                }
                .email-footer {
                    text-align: center;
                    font-size: 12px;
                    color: #888888;
                    padding: 15px;
                    background-color: #f1f1f1;
                }
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="email-header">
                    Your OTP Code
                </div>
                <div class="email-body">
                    <p>Dear %s,</p>
                    <p>We received a request to access your account. Use the OTP below to verify your identity:</p>
                    <div class="otp">%s</div>
                    <p>If you did not request this, please ignore this email.</p>
                    <p>Best regards,<br>Your Company</p>
                </div>
                <div class="email-footer">
                    &copy; 2025 JobHunting. All rights reserved.
                </div>
            </div>
        </body>
        </html>
        """, name,otp);
    }
}
