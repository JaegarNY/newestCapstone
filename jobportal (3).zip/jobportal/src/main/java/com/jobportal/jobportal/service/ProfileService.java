package com.jobportal.jobportal.service;

import com.jobportal.jobportal.exception.JobPortalException;

public interface ProfileService {
    public Long createProfile(String email) throws JobPortalException;
}
